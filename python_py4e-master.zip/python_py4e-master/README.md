# Python Basic Projects

Python Projects (include Python for Everybody Specialization, other python projects)

**Course 1:** Programming for Everybody (Getting Started with Python)

**Course 2:** Python Data Structures

**Course 3:** Using Python to Access Web Data

**Course 4:** Using Databases with Python

**Course 5:** Capstone: Retrieving, Processing, and Visualizing Data with Python

```
code3: https://www.py4e.com/materials
geeksforgeeks: crawl python data in geeksforgeeks
PE: material for PE in FPT
more material
```

and mores (like password-keeper, find gps, ...)

Difference between BFS and DFS



 **BFS** stands for **Breadth First Search**


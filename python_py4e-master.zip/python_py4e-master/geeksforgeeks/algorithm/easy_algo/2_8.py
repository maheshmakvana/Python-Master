Role of SemiColon in various Programming Languages



 **Semicolon** is a punctuation mark (;) indicating a pause, typically between
two main clauses, that is more pronounced than that indicated by a comma. In
programming, Semicolon symbol plays a vital role. It is used to show the
termination of instruction in various programming languages as well, like **C,
C++, Java, JavaScript and Python**.

In this article, let us see the act of Semicolon in different programming
languages:  
  
 ** _

Role of Semicolon in C:

_**


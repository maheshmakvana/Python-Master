friends = ['A', 'B', 'C']

for friend in friends:
    print('Hello', friend)

for i in range(len(friends)):
    friend = friends[i]
    print('Hello', friend)
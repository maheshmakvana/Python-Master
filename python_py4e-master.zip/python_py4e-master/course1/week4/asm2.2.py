# 2.2 Write a program that uses input to prompt a user for their name and then welcomes them. Note that input will pop up a dialog box. Enter Sarah in the pop-up box when you are prompted so your output will match the desired output.

name = input('Enter your name: ')
print('Hello ' + name)

# random 
import random
random_number = random.random()
random_number = random.randint(12, 50)
t = [1, 2, 3]
random.choice(t)
print(random_number)